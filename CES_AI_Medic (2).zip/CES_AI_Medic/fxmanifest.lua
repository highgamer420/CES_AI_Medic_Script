fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Crazy Eyes Studio'
description 'Advanced AI Medic Script - QBCore & Standalone Compatible'
version '1.0.0'

client_scripts {
    'config.lua',
    'utils_client.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
    'utils_server.lua',
    'server.lua'
}