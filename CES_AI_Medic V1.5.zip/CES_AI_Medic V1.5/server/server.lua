-- server/server.lua
-- =================================================================================
--      SCRIPT CREDIT
-- =================================================================================
--      This script was created by CES.
-- =================================================================================
-- print('-------------------------------------------------')
-- print('^2[CES] Ride Share has started successfully.^0')
-- print('^2Thanks for using this resource!^0')
-- print('^2Join the discord for support https://discord.gg/sNANv4dJad!^0')
-- print('-------------------------------------------------')

-- ===== STYLISH VERSION CHECK =====

-- Paste the raw GitHub URL for this script's version file here
local versionUrl = "https://raw.githubusercontent.com/highgamer420/CES-Version-Check/refs/heads/main/F-CES_AI_Medic.txt"
-- Your Discord link or website
local discordLink = "https://discord.gg/sNANv4dJad"

-- This is the function that prints our cool banner
local function printBanner(currentVersion, latestVersion)
    local resourceName = GetCurrentResourceName()
    local isUpToDate = (currentVersion == latestVersion)

    -- Set colors based on update status
    -- ^5 = Magenta, ^2 = Green, ^3 = Yellow, ^7 = White
    local latestVersionColor = isUpToDate and "^2" or "^3"
    local updateMessage = isUpToDate and "You are on the latest version!" or "An update is available! Get it from GitHub https://github.com/highgamer420/CES_AI_Medic_Script" -- is it Keymaster or GitHub
    local updateMessageColor = isUpToDate and "^2" or "^3"

   -- ASCII Art for "CES"
    local banner = {
        "|-----------------------------------------------------------------------|",
        "|                ^5Crazy Eyes Studio^7                                  |",
        "|-----------------------------------------------------------------------|",
        string.format("|         SCRIPT: %-48s  |", resourceName),
        "|-----------------------------------------------------------------------|",
        string.format("|      INSTALLED: %-12s LATEST STABLE: %s%-15s^7 |", currentVersion, latestVersionColor, latestVersion),
        "|-----------------------------------------------------------------------|",
        string.format("|      %s%-60s^7 |", updateMessageColor, updateMessage),
        string.format("|      Updates, Support, Feedback: %-30s |", discordLink),
        "|-----------------------------------------------------------------------|"
    }
    -- Print each line of the banner
    for _, line in ipairs(banner) do
        print(line)
    end
end

-- This code runs when the resource starts
Citizen.CreateThread(function()
    -- Wait 10 seconds for everything to load before checking
    Citizen.Wait(10000)

    PerformHttpRequest(versionUrl, function(errorCode, resultText, resultHeaders)
        if errorCode == 200 then
            -- We successfully fetched the latest version number
            local latestVersion = resultText:match("^%s*(.-)%s*$") -- Trim whitespace
            local currentVersion = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)

            -- Print the banner with the version info we found
            printBanner(currentVersion, latestVersion)
        else
            -- If we couldn't fetch the version, print a simple error
            print(string.format("[CES] ^1Could not check for updates for %s.^7", GetCurrentResourceName()))
        end
    end)
end)

-- ===== END VERSION CHECK =====
-- ===== END VERSION CHECK =====
-- ===== END VERSION CHECK =====

RegisterCommand('callmedic', function(source)
    print('[AI Medic] callmedic command triggered by source: ' .. source)
    local onlineEMS = 0
    if Utils.QBCore then
        for _, id in pairs(Utils.QBCore.Functions.GetPlayers()) do
            local ply = Utils.QBCore.Functions.GetPlayer(id)
            if ply and ply.PlayerData.job.name == "ambulance" then
                onlineEMS = onlineEMS + 1
            end
        end
        print('[AI Medic] Online EMS count: ' .. onlineEMS)
    end

    if onlineEMS > Config.MaxEMSOnline then
        Utils.Notify(source, "EMS are available, please call them instead.", "error")
        return
    end

    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    if not coords then
        print('[AI Medic] Failed to get coords for source: ' .. source)
        Utils.Notify(source, "Error: Could not get your location.", "error")
        return
    end
    print('[AI Medic] Triggering revivePlayer for source: ' .. source .. ' at coords: ' .. tostring(coords))
    TriggerClientEvent('custom_aimedic:revivePlayer', source, coords)
end, false)

RegisterNetEvent('custom_aimedic:chargePlayer')
AddEventHandler('custom_aimedic:chargePlayer', function(target)
    local src = target or source
    print('[AI Medic] Charging player: ' .. src)
    local Player = Utils.GetPlayerFramework(src)
    if Player then
        if Utils.RemoveMoney(Player, Config.Fee) then
            Utils.Notify(src, "You were charged $" .. Config.Fee .. " for EMS service.", "success")
        else
            Utils.Notify(src, "You don't have enough money to pay for EMS!", "error")
        end
    else
        print('[AI Medic] No player framework for source: ' .. src)
        Utils.Notify(src, "EMS fee skipped due to server error.", "error")
    end
end)

-- Custom revive event for standalone mode
RegisterNetEvent('custom_aimedic:revivePlayer')
AddEventHandler('custom_aimedic:revivePlayer', function(target)
    print('[AI Medic] Revive requested for target: ' .. target)
    if Utils.QBCore then
        -- Use QBCore's revive event (adjust based on your QBCore version)
        TriggerClientEvent('hospital:client:Revive', target) -- Common QBCore revive event
    else
        -- Standalone revive logic
        TriggerClientEvent('custom_aimedic:standaloneRevive', target)
    end
end)